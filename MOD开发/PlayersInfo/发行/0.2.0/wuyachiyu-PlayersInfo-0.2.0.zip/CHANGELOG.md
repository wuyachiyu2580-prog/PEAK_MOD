# Changelog

## [0.2.0] - 2026-08-14

### Changed
- Changed the default teammate HUD anchor from the top-left corner to the bottom-left corner.
- Existing 0.1.1 and earlier configurations that still use the old `TopLeft` value are migrated to `BottomLeft` on startup. The other anchor values are preserved.
- Extra stamina now shows the current value and the petrify-aware cap, such as `+45/70`.
- Added stable teammate bar ordering. Distance-based ordering remains available through configuration.

### Compatibility
- Updated compatibility for PEAK 2.1.a, including petrify display and the newer backpack slot API.

### Notes
- PlayersInfo remains display-only and does not change gameplay or networking state.
